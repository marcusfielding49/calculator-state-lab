import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculator State Lab',
      home: const CalculatorPage(),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String display = "0";
  double accumulator = 0;
  String? pendingOperator;

  bool awaitingOperand = false;
  bool justCalculated = false;

  String pressedButton = "";

  void numberPressed(String number) {
    setState(() {
      if (display == "0" ||
          awaitingOperand ||
          justCalculated ||
          display == "Error") {
        display = number;
        awaitingOperand = false;
        justCalculated = false;
      } else {
        display += number;
      }
    });
  }

  double performCalculation(
      double left,
      double right,
      String operator,
      ) {
    switch (operator) {
      case "+":
        return left + right;

      case "-":
        return left - right;

      case "×":
        return left * right;

      case "÷":
        if (right == 0) {
          throw Exception("Divide by zero");
        }
        return left / right;

      default:
        return right;
    }
  }

  void operatorPressed(String op) {
    setState(() {
      if (display == "Error") {
        clearAll();
        return;
      }

      double currentValue = double.parse(display);

      if (pendingOperator == null) {
        accumulator = currentValue;
      } else if (!awaitingOperand) {
        try {
          accumulator = performCalculation(
            accumulator,
            currentValue,
            pendingOperator!,
          );

          display = removeDecimal(accumulator);
        } catch (e) {
          display = "Error";
          accumulator = 0;
          pendingOperator = null;
          return;
        }
      }

      pendingOperator = op;
      awaitingOperand = true;
      justCalculated = false;
    });
  }

  void equalsPressed() {
    if (pendingOperator == null || awaitingOperand) {
      return;
    }

    setState(() {
      try {
        double currentValue = double.parse(display);

        accumulator = performCalculation(
          accumulator,
          currentValue,
          pendingOperator!,
        );

        display = removeDecimal(accumulator);

        pendingOperator = null;
        awaitingOperand = false;
        justCalculated = true;
      } catch (e) {
        display = "Error";
        accumulator = 0;
        pendingOperator = null;
      }
    });
  }

  void clearAll() {
    setState(() {
      display = "0";
      accumulator = 0;
      pendingOperator = null;
      awaitingOperand = false;
      justCalculated = false;
    });
  }

  String removeDecimal(double value) {
    if (value == value.toInt()) {
      return value.toInt().toString();
    }

    return value
        .toStringAsFixed(6)
        .replaceAll(RegExp(r'0+$'), '')
        .replaceAll(RegExp(r'\.$'), '');
  }

  Widget calculatorButton(
      String text,
      VoidCallback onPressed, {
        Color color = Colors.green,
      }) {
    bool isPressed = pressedButton == text;

    return GestureDetector(
      onTapDown: (_) {
        setState(() {
          pressedButton = text;
        });
      },
      onTapUp: (_) {
        setState(() {
          pressedButton = "";
        });

        onPressed();
      },
      onTapCancel: () {
        setState(() {
          pressedButton = "";
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        margin: const EdgeInsets.all(4),
        transform: Matrix4.identity()
          ..scale(isPressed ? 0.92 : 1.0),
        child: ElevatedButton(
          onPressed: null,
          style: ElevatedButton.styleFrom(
            disabledBackgroundColor: color,
            disabledForegroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          "Calculator State Lab",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
      ),

      body: Column(
        children: [
          Expanded(
            flex: 2,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.all(15),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.black,
                border: Border.all(
                  color: Colors.greenAccent,
                  width: 2,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    pendingOperator == null
                        ? ""
                        : "${removeDecimal(accumulator)} $pendingOperator",
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 28,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    display,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 42,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),

          Expanded(
            flex: 5,
            child: GridView.count(
              crossAxisCount: 4,
              padding: const EdgeInsets.all(8),
              children: [
                calculatorButton(
                  "AC",
                  clearAll,
                  color: Colors.redAccent,
                ),
                calculatorButton(
                  "÷",
                  () => operatorPressed("÷"),
                  color: Colors.green,
                ),
                calculatorButton(
                  "×",
                  () => operatorPressed("×"),
                  color: Colors.green,
                ),
                calculatorButton(
                  "-",
                  () => operatorPressed("-"),
                  color: Colors.green,
                ),
                calculatorButton(
                  "7",
                  () => numberPressed("7"),
                ),
                calculatorButton(
                  "8",
                  () => numberPressed("8"),
                ),
                calculatorButton(
                  "9",
                  () => numberPressed("9"),
                ),
                calculatorButton(
                  "+",
                  () => operatorPressed("+"),
                  color: Colors.green,
                ),
                calculatorButton(
                  "4",
                  () => numberPressed("4"),
                ),
                calculatorButton(
                  "5",
                  () => numberPressed("5"),
                ),
                calculatorButton(
                  "6",
                  () => numberPressed("6"),
                ),
                calculatorButton(
                  "=",
                  equalsPressed,
                  color: Colors.orange,
                ),
                calculatorButton(
                  "1",
                  () => numberPressed("1"),
                ),
                calculatorButton(
                  "2",
                  () => numberPressed("2"),
                ),
                calculatorButton(
                  "3",
                  () => numberPressed("3"),
                ),
                calculatorButton(
                  "0",
                  () => numberPressed("0"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}